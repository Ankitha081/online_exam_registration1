<?php
// Check if 'exam' is set in the URL
$exam_name = isset($_GET['exam']) ? htmlspecialchars($_GET['exam']) : "Unknown Exam";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Payment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h2 class="text-center text-primary">Fee Payment for <?= $exam_name; ?></h2>
            <p class="text-center">Please complete the payment to register.</p>
            
            <form action="process_payment.php" method="POST" class="mt-4">
                <input type="hidden" name="exam_name" value="<?= $exam_name; ?>">
                
                <div class="mb-3">
                    <label class="form-label">Your Name</label>
                    <input type="text" name="student_name" class="form-control" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Amount (₹)</label>
                    <input type="text" name="amount" value="500" class="form-control" readonly>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="form-select" required>
                        <option value="UPI">UPI</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Debit Card">Debit Card</option>
                        <option value="Net Banking">Net Banking</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-success w-100">Proceed to Payment</button>
            </form>
        </div>
    </div>
</body>
</html>
