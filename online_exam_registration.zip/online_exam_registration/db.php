<?php
$host = "localhost";
$user = "root"; // Change if different
$password = ""; // Change if you have a password
$database = "exam_db"; // Make sure this is the correct database name

$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
