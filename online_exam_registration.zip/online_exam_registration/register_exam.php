<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "exam_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = $_POST['student_name'];
    $exam_name = $_POST['exam_name'];
    $exam_date = $_POST['exam_date'];

    $sql = "INSERT INTO exam_registrations (student_name, exam_name, exam_date) VALUES ('$student_name', '$exam_name', '$exam_date')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register for Exam</title>
</head>
<body>
    <h2>Exam Registration</h2>
    <form method="POST" action="register_exam.php">
        <label>Your Name:</label>
        <input type="text" name="student_name" required>
        <br>
        <label>Exam Name:</label>
        <input type="text" name="exam_name" required>
        <br>
        <label>Exam Date:</label>
        <input type="date" name="exam_date" required>
        <br>
        <input type="submit" value="Register">
    </form>
</body>
</html>
