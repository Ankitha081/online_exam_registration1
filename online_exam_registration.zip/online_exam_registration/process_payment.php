<?php
session_start();
include 'db.php'; // Ensure db.php is in the same directory

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $student_name = $_POST['student_name'];
    $exam_name = $_POST['exam_name'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];

    // Generate a unique transaction ID
    $transaction_id = uniqid('TXN_'); 

    // Insert data into the database
    $sql = "INSERT INTO payments (transaction_id, student_name, exam_name, amount, payment_method, payment_status) 
            VALUES ('$transaction_id', '$student_name', '$exam_name', '$amount', '$payment_method', 'Pending')";

    if ($conn->query($sql) === TRUE) {
        $message = "Payment successful! Transaction ID: " . $transaction_id;
        $status = "success";
    } else {
        $message = "Error: " . $conn->error;
        $status = "danger";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Status</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 100px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .btn-home {
            text-decoration: none;
            color: white;
        }
        .btn-home:hover {
            color: white;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center">
        <div class="card text-center p-4" style="max-width: 500px;">
            <h3 class="text-<?php echo $status; ?>"><?php echo $message; ?></h3>
            <?php if ($status == "success") : ?>
                <p>Your transaction has been processed successfully.</p>
                <p><strong>Transaction ID:</strong> <?php echo $transaction_id; ?></p>
                <p><strong>Amount Paid:</strong> ₹<?php echo $amount; ?></p>
                <p><strong>Payment Method:</strong> <?php echo $payment_method; ?></p>
                <a href="index.php" class="btn btn-primary w-100">Go to Home</a>
            <?php else : ?>
                <p class="text-danger">Something went wrong. Please try again.</p>
                <a href="fee.php" class="btn btn-warning w-100">Try Again</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
