<?php
$conn = new mysqli("localhost", "root", "", "exam_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$payment_id = $_GET['payment_id'];
$result = $conn->query("SELECT * FROM payments WHERE id = $payment_id");
$payment = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h2 class="text-center text-success">Payment Successful</h2>
            <p class="text-center">Thank you for registering for <b><?= $payment['exam_name']; ?></b>.</p>

            <table class="table table-bordered mt-4">
                <tr>
                    <th>Student Name</th>
                    <td><?= $payment['student_name']; ?></td>
                </tr>
                <tr>
                    <th>Exam Name</th>
                    <td><?= $payment['exam_name']; ?></td>
                </tr>
                <tr>
                    <th>Amount Paid</th>
                    <td>₹<?= $payment['amount']; ?></td>
                </tr>
                <tr>
                    <th>Payment Method</th>
                    <td><?= $payment['payment_method']; ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td class="text-success"><?= $payment['payment_status']; ?></td>
                </tr>
            </table>

            <div class="text-center">
                <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
                <a href="dashboard.php" class="btn btn-secondary">Go to Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>
