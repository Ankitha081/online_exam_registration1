<?php
session_start();
if (!isset($_SESSION['full_name'])) {
    header("Location: login.php");
    exit();
}

include("db.php"); // Ensure database connection

$full_name = $_SESSION['full_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; text-align: center; }
        .container { width: 80%; margin: 50px auto; background: white; padding: 20px; box-shadow: 0 0 10px gray; border-radius: 10px; }
        h2 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; text-align: center; border: 1px solid #ccc; }
        th { background: blue; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .logout { display: inline-block; padding: 10px 20px; margin-top: 20px; background: red; color: white; text-decoration: none; border-radius: 5px; }
        .logout:hover { background: darkred; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Welcome, <?php echo $full_name; ?> 👋</h2>
        <h3>Available Exams</h3>
        
        <table>
            <tr>
                <th>Subject</th>
                <th>Date</th>
                <th>Time</th>
                <th>Register</th>
            </tr>
            <tr>
                <td>Software Engineering & Agile Development</td>
                <td>2025-04-10</td>
                <td>10:00 AM</td>
                <td><a href="fee.php?exam=Software Engineering & Agile Development">Register</a></td>
            </tr>
            <tr>
                <td>Compiler Design</td>
                <td>2025-04-12</td>
                <td>12:00 PM</td>
                <td><a href="fee.php?exam=Compiler Design">Register</a></td>
            </tr>
            <tr>
                <td>Parallel & Distributed Computing</td>
                <td>2025-04-14</td>
                <td>2:00 PM</td>
                <td><a href="fee.php?exam=Parallel & Distributed Computing">Register</a></td>
            </tr>
            <tr>
                <td>Data Privacy & Security</td>
                <td>2025-04-16</td>
                <td>4:00 PM</td>
                <td><a href="fee.php?exam=Data Privacy & Security">Register</a></td>
            </tr>
            <tr>
                <td>Python Programming</td>
                <td>2025-04-18</td>
                <td>10:00 AM</td>
                <td><a href="fee.php?exam=Python Programming">Register</a></td>
            </tr>
            <tr>
                <td>C Programming</td>
                <td>2025-04-20</td>
                <td>12:00 PM</td>
                <td><a href="fee.php?exam=C Programming">Register</a></td>
            </tr>
        </table>

        <a href="logout.php" class="logout">Logout</a>
    </div>
</body>
</html>
