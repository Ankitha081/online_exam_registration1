<?php
session_start();
include("db.php"); // Ensure db.php exists and contains $conn

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $password = $_POST['password'];

    // Check if user exists
    $query = "SELECT * FROM users WHERE full_name='$full_name'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $hashed_password = $row['password']; // Hashed password from DB

        // Verify the entered password with the stored hashed password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['full_name'] = $full_name; // Store session
            echo "<script>alert('Login successful! Redirecting to dashboard...'); window.location='dashboard.php';</script>";
        } else {
            echo "<script>alert('Invalid Password!');</script>";
        }
    } else {
        echo "<script>alert('User Not Found!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Fullscreen Background Image */
        body { 
            font-family: Arial, sans-serif; 
            text-align: center; 
            background: url('http://localhost/online_exam_registration/css/old-books.jpg') no-repeat center center fixed;
            background-size: cover; 
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Login Container */
        .container { 
            width: 300px; 
            padding: 20px; 
            background: rgba(255, 255, 255, 0.9); /* Semi-transparent background */
            box-shadow: 0 0 10px gray; 
            border-radius: 10px; 
        }

        /* Input Fields */
        input { 
            width: 90%; 
            padding: 10px; 
            margin: 10px 0; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
        }

        /* Login Button */
        button { 
            width: 100%; 
            padding: 10px; 
            background: blue; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
        }
        button:hover { background: darkblue; }
        
        a { text-decoration: none; color: blue; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="C:\xampp\htdocs\online_exam_registration\register.php">Register here</a></p>
    </div>
</body>
</html>
