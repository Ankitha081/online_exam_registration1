<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Exam Registration</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('http://localhost/online_exam_registration/css/old-books.jpg') no-repeat center center fixed;
            background-size: cover;
            background-color: rgb(38, 27, 116); /* Fallback color */
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(106, 13, 13, 0.1);
        }
        h1 {
            font-size: 28px;
            color: rgb(97, 43, 107);
            text-align: center;
        }
        .register-link {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <div class="container text-center">
        <h1>Welcome to Online Exam Registration</h1>
        <div class="register-link">
            <a href="/online_exam_registration/register.php" class="btn btn-primary btn-lg">Register for an Exam</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
